    Facter.add(:git_version) do
      setcode do
        command = '/usr/bin/git --version | /bin/awk \'{print $3}\''
        # IMPORTANT! The exec function has been renamed in Factor 2.x.  Be careful when reading
        # new documentation and   
        #
        # Facter 2.x:
        #Facter::Core::Resolution.exec(command)
        #
        # Facter 1.7:
        Facter::Util::Resolution.exec(command)
      end
    end
